#include "button.h"
#include "lpc17xx.h"
#include "../led/led.h"
int inct;
int key1;
int key2;


void EINT0_IRQHandler (void)	    //  inct
{
	int newInct;
	newInct = LPC_TIM0->TC;
	int gap;
	gap = newInct - inct;
	if(gap > 0x00000280){
		LED_On(0);
		inct = newInct;
	}
	LPC_SC->EXTINT |= (1 << 0);     /* clear pending interrupt         */
}


void EINT1_IRQHandler (void)	 		// key1 
{
	LED_On(1);
	LPC_SC->EXTINT |= (1 << 1);     /* clear pending interrupt         */
}

void EINT2_IRQHandler (void)	   //  key2
{
	LED_Off(0);
	LED_Off(1);
	LPC_SC->EXTINT |= (1 << 2);     /* clear pending interrupt         */    
}


